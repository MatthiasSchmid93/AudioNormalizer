def open_window() -> None:
    from . import controller
    controller.main()
    